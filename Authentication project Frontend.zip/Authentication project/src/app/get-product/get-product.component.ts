import { Component, OnInit, ViewChild } from '@angular/core';
import { RegisterService } from '../services/data.service';
import { Product } from '../shared/Product';
import { MatTableDataSource } from '@angular/material/table';
import { MatSort, Sort } from '@angular/material/sort';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { FormControl } from '@angular/forms';
import {debounceTime, distinctUntilChanged} from 'rxjs/operators'
@Component({
  selector: 'app-get-product',
  templateUrl: './get-product.component.html',
  styleUrls: ['./get-product.component.scss']
})
export class GetProductComponent implements OnInit{

  products: Product[] = [];
  showNav: boolean = true;
  displayedColumns: string[] = ['image', 'name', 'price', 'description', 'brand', 'productType'];
  dataSource!: MatTableDataSource<Product>;
  @ViewChild(MatSort) sort!: MatSort;
  @ViewChild(MatPaginator) paginator!: MatPaginator;
  filterFormControl = new FormControl('');
  filteredData: Product[]=[];

  constructor(private registerService: RegisterService) {
   }

   ngOnInit(): void {
    this.dataSource = new MatTableDataSource<Product>(this.products);
    this.dataSource.sort = this.sort;
    this.dataSource.paginator = this.paginator;
    this.filterFormControl.valueChanges
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe(filterValue => {
        this.applyFilter(filterValue);
      });
    this.getProducts();
  }
  
  applyFilter(filterValue: string | null): void {
    filterValue = filterValue?.trim().toLowerCase() || '';
    this.dataSource.filter = filterValue;
  }

  getProducts(): void {
    this.registerService.getProducts()
      .subscribe(products => {
        this.products = products;
        this.dataSource.data = this.products; // Update dataSource with fetched products
        this.dataSource.paginator?.firstPage(); // Reset the paginator to the first page
      });
  }
  
  clearFilter(): void {
    this.filterFormControl.setValue(''); 
  }
  

  getImageSource(imageData: string): string {
    return `data:image/jpeg;base64,${imageData}`;
  }
}
