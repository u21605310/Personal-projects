import { Component } from '@angular/core';
import { User } from '../shared/user';
import { AuthService } from '../services/auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  email!: string;
  password!: string;

  constructor(private authService: AuthService, private router: Router){}

  login(): void {
    if (this.email && this.password) {
      this.authService.login(this.email, this.password).subscribe(
        response => {
          const token = response.token;
          const user = response.user;
          console.log(user);
          this.router.navigate(['/getProducts']);
        },
        error => {
          console.log(error);
        }
      );
    }
  }

  isFieldEmpty(field: string): boolean {
    return field === 'email' && !this.email || field === 'password' && !this.password;
  }

  isFormInvalid(): boolean {
    return !this.email || !this.password;
  }
}
