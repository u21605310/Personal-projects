import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { RegisterUserComponent } from './register-user/register-user.component';
import { LoginComponent } from './login/login.component';
import { GetProductComponent } from './get-product/get-product.component';
import { AddProductComponent } from './add-product/add-product.component';

const routes: Routes = [
  {path: 'register', component: RegisterUserComponent},
  {path: 'login', component: LoginComponent},
  {path: 'getProducts', component: GetProductComponent},
  {path: 'AddProducts', component: AddProductComponent},
  {path: '', component: LoginComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
