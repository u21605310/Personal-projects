import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs/internal/Observable';
import { User } from '../shared/user';
import { map } from 'rxjs/operators';
import { register } from '../shared/register';
import { catchError } from 'rxjs/operators';
import { throwError } from 'rxjs';


@Injectable({
  providedIn: 'root',
})
export class AuthService {
  constructor(private http: HttpClient) {}

  public register(_Register: register): Observable<any> {
    return this.http.post<any>(
      'http://localhost:5240/api/User/Register',
      register
    );
  }

  private loginUrl = 'http://localhost:5240/api/User/Login'; // Replace with your backend login API URL

  
login(email: string, password: string): Observable<any> {
  const user = {
  emailaddress: email,
  password: password
  }
  return this.http.post<any>(this.loginUrl, user);
}
}