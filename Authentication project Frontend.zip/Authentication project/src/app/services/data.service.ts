import { Injectable } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import { Observable } from 'rxjs';
import { Product } from '../shared/Product';
import { ProductViewModel } from '../shared/addproduct';


@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  private apiUrl = 'http://localhost:5240/api/Product';
  
  constructor(private http: HttpClient) { }

  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }

  addProduct(product: ProductViewModel): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/addProducts`, product);
  }
}

