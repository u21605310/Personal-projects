import { Validators } from '@angular/forms';

export class register {

  firstName: string='';
  lastName: string='';
  emailAddress: string='';
  password: string='';
  address: string='';

  static validationMessages = {
    firstName: [
      { type: 'required', message: 'Your Name is required' }
    ],
    lastName: [
      { type: 'required', message: 'Your Surname is required' }
    ],
    emailAddress: [
      { type: 'required', message: 'Email address is required' },
      { type: 'email', message: 'Invalid email address' }
    ],
    password: [
      { type: 'required', message: 'Password is required' },
      { type: 'minlength', message: 'Password must be at least 6 characters long' }
    ],
    address: [
      { type: 'required', message: 'Address is required' }
    ]
  };

  static formValidations = {
    firstName: ['', [Validators.required]],
    lastName: ['', [Validators.required]],
    emailAddress: ['', [Validators.required, Validators.email]],
    password: ['', [Validators.required, Validators.minLength(6)]],
    address: ['', [Validators.required]]
  };
}

