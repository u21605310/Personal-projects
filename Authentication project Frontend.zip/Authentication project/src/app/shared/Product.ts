export interface Product {
    productId: number;
    price: number;
    image: string;
    brandId: number;
    productTypeId: number;
    productType: {
      productTypeId: number;
      name: string;
      description: string;
      dateCreated: string;
      dateModified: string;
      isActive: boolean;
      isDeleted: boolean;
    };
    brand: {
      brandId: number;
      name: string;
      description: string;
      dateCreated: string;
      dateModified: string;
      isActive: boolean;
      isDeleted: boolean;
    };
    name: string;
    description: string;
    dateCreated: string;
    dateModified: string;
    isActive: boolean;
    isDeleted: boolean;
  }
  