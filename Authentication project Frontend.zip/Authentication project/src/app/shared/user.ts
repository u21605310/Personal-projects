export class User {
    emailAddress = '';
    password = '';
}
