export interface ProductViewModel {
    name: string;
    description: string;
    price: number;
    image: string;
    brand: number;
    producttype: number;
  }
  