import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { register } from '../shared/register';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-register-user',
  templateUrl: './register-user.component.html',
  styleUrls: ['./register-user.component.scss']
})
export class RegisterUserComponent {

  user: register = new register();
  apiURL: string = 'http://localhost:5240/api/User/Register';

  constructor(private http: HttpClient, private router: Router, private snackBar: MatSnackBar) {}

  register() {
    this.http.post(this.apiURL, this.user)
      .subscribe(
        (response) => {
          console.log('Registration success!', response);
          this.router.navigate(['/login']);

          this.snackBar.open('Registered successfully!', 'Close', {
            duration: 3000,
          });
        },
        (error) => {
          console.error('Registration error:', error);
        
        }
      );
  }
}
