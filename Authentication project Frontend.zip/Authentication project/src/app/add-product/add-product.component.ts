import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from '../services/data.service';
import { Product } from '../shared/Product';
import { ProductViewModel } from '../shared/addproduct';
import { Router } from '@angular/router';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrls: ['./add-product.component.scss']
})
export class AddProductComponent  implements OnInit {
  product: ProductViewModel = {
    name: '',
    description: '',
    price: 0,
    image: '',
    brand: 0,
    producttype: 0
  };

  constructor(private registerService: RegisterService, private router: Router) { }

  ngOnInit(): void {
  }

  handleImageInput(event: any): void {
    const file: File = event.target.files[0];
    this.convertImageToBase64(file);
  }
  
  convertImageToBase64(file: File): void {
    const reader: FileReader = new FileReader();
    reader.onloadend = () => {
      const base64String: string = reader.result as string;
      const base64Data: string = base64String.split(',')[1]; // Extract base64 data part
      this.product.image = base64Data;
    };
    reader.readAsDataURL(file);
  }
  
  
  

  
  addProduct(): void {
    this.registerService.addProduct(this.product)
      .subscribe(
        response => {
          console.log("Product Added Successfully", response); 
          this.router.navigate(['/getProducts']);
        },
        error => {
          console.error("Product not addedd", error); 
        }
      );
  }
}
