import { Component, OnInit } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';
import { RestaurantService, Restaurant } from '../services/restaurant.service';
import { CommonModule } from '@angular/common';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss'],
  standalone: true,
  imports: [IonicModule, ExploreContainerComponent, CommonModule],
})


export class Tab1Page implements OnInit {

  restaurants: Restaurant[] = [];

currentDate: string;

  constructor(private restaurantService: RestaurantService, private cartService: CartService) {
    const dateObj = new Date();
    const year = dateObj.getFullYear();
    const month = dateObj.getMonth() + 1;
    const date = dateObj.getDate();
    this.currentDate = `${year}-${month < 10 ? '0' + month : month}-${date < 10 ? '0' + date : date}`;

  }
  ngOnInit() {
    this.restaurantService.restaurants$.subscribe(restaurants => {
      this.restaurants = restaurants;
    });
  }
  addRestaurantToCart(event: any, restaurant: Restaurant){
    this.cartService.addToCart(restaurant);
  }
}

