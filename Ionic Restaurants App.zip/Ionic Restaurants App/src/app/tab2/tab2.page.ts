import { Component } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';
import { RestaurantService, Restaurant } from '../services/restaurant.service';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-tab2',
  templateUrl: 'tab2.page.html',
  styleUrls: ['tab2.page.scss'],
  standalone: true,
  imports: [IonicModule, ExploreContainerComponent, CommonModule,FormsModule]
})
export class Tab2Page {

searchQuery: string = '';
restaurants: Restaurant[] = [];
  filteredRestaurants: Restaurant[] = [];

  constructor(private restaurantService: RestaurantService, private cartService: CartService) {
    this.restaurantService.restaurants$.subscribe(restaurants => {
      this.restaurants = restaurants;
      this.filteredRestaurants = restaurants;
  });
  }

  filterRestaurants() {
    if (this.searchQuery.trim() === '') {
      this.filteredRestaurants = this.restaurants;
      return;
    }

    this.filteredRestaurants = this.restaurants.filter((restaurant) => {
      return restaurant.name.toLowerCase().includes(this.searchQuery.toLowerCase());
    });
  }

  addRestaurantToCart(event: any, restaurant: Restaurant){
    this.cartService.addToCart(restaurant);
  }
}
