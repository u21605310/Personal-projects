import { Component } from '@angular/core';
import { IonicModule, NavController } from '@ionic/angular';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';
import { CartService } from '../services/cart.service';
import { Restaurant } from '../services/restaurant.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-tab3',
  templateUrl: 'tab3.page.html',
  styleUrls: ['tab3.page.scss'],
  standalone: true,
  imports: [IonicModule, ExploreContainerComponent, CommonModule],
})
export class Tab3Page {
  cart: Restaurant[] = [];
  isModalOpen = false;
    orders: any[]=[];

  constructor(private cartService: CartService, private NavController: NavController) {}

  ionViewWillEnter(){
    this.cart = this.cartService.getCart();
  }

  getTotalPrice(): number {
    let totalPrice = 0;
    let deliveryPrice= 40;
    for (const item of this.cart){
      totalPrice += Number(item.price)
    }
    return totalPrice + deliveryPrice;
  }

  checkout() {
    this.cartService.cart = this.cart;
    this.NavController.navigateForward('../tab4/tab4.page.html');
  }

  setOpen(isOpen: boolean){
    this.isModalOpen = isOpen;
  }
  pastOrder() {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.orders = this.cartService.cart
  }
}
