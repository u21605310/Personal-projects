import { Component, EnvironmentInjector, inject } from '@angular/core';
import { IonicModule } from '@ionic/angular';
import { CommonModule } from '@angular/common';
import { UserService } from './services/user.service';


@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule],
})
export class AppComponent {
  public environmentInjector = inject(EnvironmentInjector);

  constructor(private userService: UserService) {
    this.userService.addUser({ id: 1, name: 'Lutho Nyakeni', email: 'Luthonyakeni@gmail.com', number: '0648947851', address: "976 Park Street, Arcadia, Pretoria" });

    const users = this.userService.getUsers();
    console.log(users);
  }
}

localStorage.setItem('restaurants', JSON.stringify([
  {
    id: 1,
    name: "Big Mac Meal",
    description: " American fast-food company that is one of the largest and most popular in the world",
    imageUrl: "../assets/Mcdonalds.png",
    rating: 4.5,
    price: 90,
    location: "1115 Burnett St, Hatfield, Pretoria"
  },
  {
    id: 2,
    name: " Chicken Schwarma Meal",
    description: "The Mochachos fast-casual dining concept is unique and creates an equally distinctive customer experience.",
    imageUrl: "../assets/Mochachos.jpeg",
    rating: 4.8,
    price: 80,
    location: "1122 Burnnet Street, Hatfield, Pretoria"
  },
  {
    id: 3,
    name: "Creamy Chicken Triple Decker",
    description: "Getting your fave pizza is easy with Debonairs Pizza.",
    imageUrl: "../assets/Debonairs.jpeg",
    rating: 4.3,
    price: 65,
    location: "1122 Burnett Street, Hatfield, Pretoria"
  }
]));
