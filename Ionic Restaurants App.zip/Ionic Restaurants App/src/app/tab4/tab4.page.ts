import { RestaurantService, Restaurant } from './../services/restaurant.service';
import { Component, EnvironmentInjector, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { User } from '../services/user.interface';
import { UserService } from '../services/user.service';
import { ExploreContainerComponent } from '../explore-container/explore-container.component';
import { CartService } from '../services/cart.service';

@Component({
  selector: 'app-tab4',
  templateUrl: './tab4.page.html',
  styleUrls: ['./tab4.page.scss'],
  standalone: true,
  imports: [IonicModule, CommonModule, FormsModule, ExploreContainerComponent]
})

export class Tab4Page {
  users: User[] = [];
  isEditing = false;
  orders: any[]=[];
  isModalOpen =false;

  constructor(private userService: UserService, private cartService: CartService) {}
  ionViewDidEnter() {
    this.users = this.userService.getUsers();
  }

  editUser(user: User) {
    const index = this.users.findIndex(u => u.id === user.id);
    if (index !== -1) {
      this.users[index] = user;
      localStorage.setItem('users', JSON.stringify(this.users));
      this.isEditing = true;
    }
  }

  saveUser(user: User) {
    const index = this.users.findIndex(u => u.id === user.id);
    if (index !== -1) {
      this.users[index] = user;
      localStorage.setItem('users', JSON.stringify(this.users));
      this.isEditing = false; // disable textboxes
    }
  }

  ngOnInit(): void {
    //Called after the constructor, initializing input properties, and the first call to ngOnChanges.
    //Add 'implements OnInit' to the class.
    this.orders = this.cartService.cart
  }

  setOpen(isOpen: boolean) {
    this.isModalOpen = isOpen;
  }

  addRestaurantToCart(event: any, orders: any){
    this.cartService.addToCart(orders);
  }
}
