import { Injectable } from '@angular/core';
import { User } from '../services/user.interface';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  private users: User[] = [];

  constructor() { }

  addUser(user: User) {
    this.users.push(user);
    localStorage.setItem('users', JSON.stringify(this.users));
  }

  getUsers() {
    const users = JSON.parse(localStorage.getItem('users') || '[]');
    this.users = users;
    return users;
  }
}
