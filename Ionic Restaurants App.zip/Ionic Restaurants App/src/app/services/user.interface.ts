export interface User {
  id: number;
  name: string;
  email: string;
  number: string;
  address: string;
}
