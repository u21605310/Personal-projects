import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

export interface Restaurant {
  id: number;
  name: string;
  description: string;
  imageUrl: string;
  rating: number;
  price: string;
  location: string;
}

@Injectable({
  providedIn: 'root'
})
export class RestaurantService {
  private readonly _restaurants = new BehaviorSubject<Restaurant[]>([]);
  readonly restaurants$ = this._restaurants.asObservable();

  constructor() {
    this.loadInitialData();
  }

  private loadInitialData(): void {
    const restaurants = JSON.parse(localStorage.getItem('restaurants') || '[]');
    this._restaurants.next(restaurants);
  }
}
