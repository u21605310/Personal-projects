import { Injectable } from '@angular/core';
import { Restaurant } from '../services/restaurant.service';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  cart: Restaurant[] = [];
  myCart: any[] = [];

  addToCart(restaurant: Restaurant) {
    this.cart.push(restaurant);
  }

  getCart() {
    return this.cart;
  }
}
