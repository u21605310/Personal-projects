﻿using Microsoft.AspNetCore.Identity;

namespace Assignment3_Backend.Models
{
    public class AppUser: IdentityUser
    {
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string Address { get; set; }
    }
}
