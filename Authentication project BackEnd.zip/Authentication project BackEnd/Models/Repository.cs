﻿using Microsoft.EntityFrameworkCore;

namespace Assignment3_Backend.Models
{
    public class Repository:IRepository
    {
        private readonly AppDbContext _appDbContext;

        public Repository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public void Add<T>(T entity) where T : class
        {
            _appDbContext.Add(entity);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _appDbContext.SaveChangesAsync() > 0;
        }

        public async Task<List<Product>> GetProductsAsync()
        {

            List<Product> products = await _appDbContext.Products
                .Join(_appDbContext.Brands, p => p.BrandId, b => b.BrandId, (p, b) => new { Product = p, BrandName = b.Name })
                .Join(_appDbContext.ProductTypes, pb => pb.Product.ProductTypeId, pt => pt.ProductTypeId, (pb, pt) => new Product
                {
                    ProductId = pb.Product.ProductId,
                    Price = pb.Product.Price,
                    Image = pb.Product.Image,
                    BrandId = pb.Product.BrandId,
                    ProductTypeId = pb.Product.ProductTypeId,
                    Name = pb.Product.Name,
                    ProductType = new ProductType
                    {
                        ProductTypeId = pt.ProductTypeId,
                        Name = pt.Name,
                        Description = pt.Description,
                        DateCreated = pt.DateCreated,
                        DateModified = pt.DateModified,
                        IsActive = pt.IsActive,
                        IsDeleted = pt.IsDeleted
                    },
                    Brand = new Brand
                    {
                        BrandId = pb.Product.BrandId,
                        Name = pb.BrandName,
                        Description = null,
                        DateCreated = pb.Product.DateCreated,
                        DateModified = pb.Product.DateModified,
                        IsActive = pb.Product.IsActive,
                        IsDeleted = pb.Product.IsDeleted
                    }
                })
                .ToListAsync();

            return products;
        }

        public async Task<Product> AddProductAsync(Product product)
        {
            _appDbContext.Products.Add(product);
            await _appDbContext.SaveChangesAsync();
            return product;
        }

        public async Task<Product> DeleteProductAsync(int id)
        {
            var product = await _appDbContext.Products.FindAsync(id);
            if (product == null)
                return null;

            _appDbContext.Products.Remove(product);
            await _appDbContext.SaveChangesAsync();
            return product;
        }
    }
}
