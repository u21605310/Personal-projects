﻿using Assignment3_Backend.Models;
using Assignment3_Backend.ViewModels;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Assignment3_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserManager<AppUser> _userManager;
        private readonly IUserClaimsPrincipalFactory<AppUser> _claimsPrincipalFactory;
        private readonly IConfiguration _configuration;

        private readonly IAuthenticationService _authenticationService;
        private readonly ILogger<UserController> _logger;

        public UserController(UserManager<AppUser> userManager, IUserClaimsPrincipalFactory<AppUser> claimsPrincipalFactory, IConfiguration configuration, ILogger<UserController> logger, IAuthenticationService authenticationService)
        {
            _userManager = userManager;
            _claimsPrincipalFactory = claimsPrincipalFactory;
            _logger = logger;
            _authenticationService = authenticationService;
            _configuration = configuration;
        }

        [HttpPost]
        [Route("Register")]
        public async Task<IActionResult> Register(RegistrationViewModel uvm)
        {
            var registerUser = await _userManager.FindByEmailAsync(uvm.Emailaddress);

            if (registerUser == null)
            {
                registerUser = new AppUser
                {
                    Id = Guid.NewGuid().ToString(),
                    firstName = uvm.FirstName,
                    lastName = uvm.LastName,
                    UserName = uvm.Emailaddress,
                    Email = uvm.Emailaddress,
                    Address = uvm.Address,


                };

                var result = await _userManager.CreateAsync(registerUser, uvm.Password);

                if (result.Errors.Count() > 0) return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");

                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

            }
            else
            {
                return Forbid("Account already exists.");
            }

            return Ok();
        }


        [HttpPost]
        [Route("Login")]
        public async Task<ActionResult> Login(UserViewModel uvm)
        {
            var loginUser = await _userManager.FindByNameAsync(uvm.Emailaddress);

            if (loginUser != null && await _userManager.CheckPasswordAsync(loginUser, uvm.Password))

            {
                try
                {
                    return GenerateJWTToken(loginUser);
                }
                catch (Exception)
                {
                    return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
                }
            }
            else
            {
                return NotFound("Does not exist");
            }
        }

        [HttpGet]
        private ActionResult GenerateJWTToken(AppUser user)
        {
            // Create JWT Token
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Tokens:Key"]));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["Tokens:Issuer"],
                _configuration["Tokens:Audience"],
                claims,
                signingCredentials: credentials,
                expires: DateTime.UtcNow.AddHours(3)
            );

            return Created("", new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token),
                user = user.UserName
            });
        }
    }
}