﻿using Assignment3_Backend.Models;
using Assignment3_Backend.ViewModels;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace Assignment3_Backend.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductController : ControllerBase
    {
        private readonly IRepository _repository;

        public ProductController(IRepository repository)
        {
            _repository = repository;
        }

        [HttpGet]
        public async Task<IActionResult> GetProducts()
        {
            var products = await _repository.GetProductsAsync();
            return Ok(products);
        }

        [HttpPost]
        [Route("addProducts")]
        public async Task<IActionResult> AddProduct(ProductViewModel productViewModel)
        {
            var product = new Product
            {
                Name = productViewModel.name,
                Description = productViewModel.description,
                Price = productViewModel.price,
                Image = productViewModel.image,
                BrandId = productViewModel.brand,
                ProductTypeId = productViewModel.producttype
            };

            var addedProduct = await _repository.AddProductAsync(product);
            return Ok(addedProduct);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            var deletedProduct = await _repository.DeleteProductAsync(id);
            if (deletedProduct == null)
            {
                return NotFound();
            }

            return Ok(deletedProduct);
        }
    }
}
